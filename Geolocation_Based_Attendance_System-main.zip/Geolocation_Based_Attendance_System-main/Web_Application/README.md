# Geolocation_Based_Attendance_System
It is a simple app that helps to track employees'/students' attendance details.
